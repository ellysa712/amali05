<?php
include('config.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>404 ! Sorry</title>
</head>
<body><br><br><br>
<center>
	<img src="img\sedih.gif">
	<h1>404 Page Not Found</h1>
	<h3>Sorry This Page Isn't Available</h3>
	<a href="index.php"></a><p>Go Back</p>
</center>
</body>
</html>